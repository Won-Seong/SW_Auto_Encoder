import torch.nn as nn

def make_attn(in_channels):
    return nn.Identity(in_channels)
    